<?php

return [
    'can_see_all_records_role_id' => 1
];