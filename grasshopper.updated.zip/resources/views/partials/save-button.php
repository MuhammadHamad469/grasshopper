<button type="submit" class="btn btn-success mt-3">
    <i class="fas fa-save"></i> Save <!-- Font Awesome save icon -->
</button>