<div class="card bg-primary text-white">
    <div class="card-body">
        <h5 class="card-title">
            <i class="fa fa-users"></i> {{ $title }}
        </h5>
        <p class="card-text display-4">{{ $value }}</p>
    </div>
</div>