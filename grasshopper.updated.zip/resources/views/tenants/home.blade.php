@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">@lang('Contour Enviro Group')</div>


                <div class="panel-body">
                    <div class="row gap-6">
                        <div class="col-md-3  bg-yellow text-center">USERS <br>ggv bhewcergnyhgrcgrem wt cwtuhmcwe yh
                            ghvn r gi
                        </div>
                        <div class="col-md-3  bg-red  text-center">MY WORKSPACE <br>ggv bhewcergnyhgrcgrem wt cwtuhmcwe
                            yh ghvn r gi
                        </div>
                        <div class="col-md-3  bg-green  text-center">ASSETS <br>ggv bhewcergnyhgrcgrem wt cwtuhmcwe yh
                            ghvn r gi
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection