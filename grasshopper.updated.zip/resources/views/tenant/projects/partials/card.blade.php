<div class="col-md-3 project-card-container">
    <div class="project-card text-blue">
        <div class="project-card-body">
            <h5 class="project-card-title">{{$title}}</h5>
            <p class="project-card-text">{{$text}}</p>
        </div>
    </div>
</div>