<div class="col-md">
<div class="row mb-4">
    <div class="col-12">
        <h1 class="mb-0 mr-3">{{ $project->project_name }}</h1>
        <h4 class="text-muted-sub">{{ $project->projectType->name }} | {{$project->startDate}} - {{$project->endDate}}</h4>
    </div>
</div>
</div>